function show() {
    
    var shown = document.getElementById('menu2');
    if (shown.style.display === "none") {
        shown.style.display = "flex";
        
    } else {
        shown.style.display = "none"
        
    }
}